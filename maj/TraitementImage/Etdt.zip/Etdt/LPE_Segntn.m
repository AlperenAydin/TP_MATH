%Segmentation par ligne de partage des eaux
%Octobre 2012
%Utilisation de FAH

close all
clear all
clc

tic
CQueue

num=1; %correspond � diff�rentes images
switch num
    case 1
        I=[8 5 5 6 5 7
            6 3 3 5 4 5
            4 1 1 3 5 8
            8 4 3 4 6 4
            9 10 10 6 3 3
            9 10 10 5 4 4
            ];
        mini=[9, 15, 26, 29, 35];
        plateau=false; %pas de fond trait� comme marqueur : toute l'image est partionn�e
    case 2
        I0=imread('Image2.gif');
        figure(2),imagesc(I0),colormap gray, title('I0');
        I=Distance(I0,0); %se sera l'image sur laquelle est effectu�e la LPE
        [mini, Minima]=Minimum(I,0.015); %recherche des minima �tendus
        
        I=im2uint8(I) + 1; %un indice de la FAH=un ng => on passe en entier non sign�
        plateau=true; %Le fond n'est pas trait�=un marqueur
    case 3
        I0=rgb2gray(imread('Image3.jpg'));
        %A compl�ter
        
end

[H W]=size(I);
figure(1),imagesc(I),colormap gray

%Carte des minima = les marqueurs
L=zeros(H,W);
L(mini)=1;
[L n]=bwlabel(L);

%Ajout des pixels du fond aux marqueurs
if plateau
    ind=find(I==1);
    n=n+1;
    L(ind)=n;
end
figure(3),imagesc(L);

%Cr�ation du "tableau de queues" i.e. FAH
ng=I(:);
ng=unique(ng);
for i=1:length(ng)
    FAH(ng(i))=CQueue();
end


t=toc;
fprintf('\nRuning time %f s',t);






